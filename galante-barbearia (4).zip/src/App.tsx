import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { GallerySection } from './components/GallerySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { SERVICES } from './data/barbershop';

export default function App() {
  const [selectedService, setSelectedService] = useState<string>(SERVICES[0].name);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[hsl(var(--bg-canvas))] text-[hsl(var(--text-primary))]">
        <Navbar />
        <main>
          <Hero />
          <ServicesSection onSelectService={setSelectedService} />
          <AboutSection />
          <GallerySection />
          <ContactSection
            selectedService={selectedService}
            onServiceChange={setSelectedService}
          />
        </main>
        <Footer />
      </div>
    </MotionConfig>
  );
}
