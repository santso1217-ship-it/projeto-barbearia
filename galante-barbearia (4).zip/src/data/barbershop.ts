export interface BarberService {
  id: string;
  index: string;
  name: string;
  price: string;
  numericPrice: number;
  duration: string;
  description: string;
  image: string;
  imageAlt: string;
  featured?: boolean;
}

export interface StatMetric {
  value: string;
  label: string;
}

export const WHATSAPP_NUMBER_RAW = '5519984064616';
export const PHONE_DISPLAY = '+55 19 98406-4616';
export const ADDRESS_DISPLAY = 'R. Ângelo Ôngaro, 300 - Centro, Sumaré - SP, 13170-024';

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER_RAW}?text=${encodeURIComponent(message)}`;
}

export const HERO_IMAGE = '/src/assets/images/hero_barbearia_galante_1794579275772.jpg';
export const GALLERY_PORTRAIT_IMAGE = '/src/assets/images/galeria_arte_barbearia_1794579276522.jpg';

export const SERVICES: BarberService[] = [
  {
    id: 'corte-masculino',
    index: '01',
    name: 'Corte Masculino',
    price: 'R$ 60',
    numericPrice: 60,
    duration: '45 min',
    description:
      'Visagismo, tesoura e acabamento preciso na navalha para um caimento impecável no dia a dia.',
    image: '/src/assets/images/servico_corte_masculino_1794579275733.jpg',
    imageAlt: 'Barbeiro realizando corte masculino com tesoura e pente na Galante Barbearia',
    featured: true,
  },
  {
    id: 'barba',
    index: '02',
    name: 'Barba',
    price: 'R$ 45',
    numericPrice: 45,
    duration: '35 min',
    description:
      'Alinhamento com toalha quente, navalha clássica e bálsamo calmante.',
    image: '/src/assets/images/servico_barba_toalha_1794579276247.jpg',
    imageAlt: 'Barbeiro fazendo barba com navalha e toalha quente em cadeira clássica',
  },
  {
    id: 'tratamento-capilar',
    index: '03',
    name: 'Tratamento Capilar',
    price: 'R$ 80',
    numericPrice: 80,
    duration: '40 min',
    description:
      'Higienização profunda, óleos botânicos e massagem revitalizante para couro cabeludo e fios.',
    image: '/src/assets/images/servico_tratamento_capilar_1794579276911.jpg',
    imageAlt: 'Ritual de tratamento capilar com óleos e massagem na Galante Barbearia',
  },
];

export const TRADITION_STATS: StatMetric[] = [
  {
    value: '15+',
    label: 'Anos de experiência',
  },
  {
    value: '10.000+',
    label: 'Clientes atendidos',
  },
  {
    value: '5',
    label: 'Barbeiros especialistas',
  },
  {
    value: '4.9',
    label: 'Nota de avaliação',
  },
];
