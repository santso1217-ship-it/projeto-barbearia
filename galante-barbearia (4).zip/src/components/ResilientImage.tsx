import { useState } from 'react';
import { Scissors } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
  aspectClassName?: string;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  priority = false,
  aspectClassName = '',
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-3 bg-[hsl(var(--bg-surface))] border border-[hsl(var(--border-subtle))] text-[hsl(var(--text-muted))] p-6 ${aspectClassName} ${className}`}
      >
        <Scissors className="w-6 h-6 text-[hsl(var(--accent-gold))]" aria-hidden="true" />
        <span className="text-xs tracking-wider text-center max-w-[24ch]">{alt}</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-[hsl(var(--bg-deep))] ${aspectClassName}`}>
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        loading={priority ? 'eager' : 'lazy'}
        decoding={priority ? 'sync' : 'async'}
        onLoad={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        className={`w-full h-full object-cover transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        } ${className}`}
      />
    </div>
  );
}
