import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { buildWhatsAppUrl } from '../data/barbershop';

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#galeria', label: 'Galeria' },
  { href: '#contato', label: 'Contato' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 36);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de conversar e agendar um horário na Galante Barbearia.'
  );

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-200 ${
        scrolled || mobileOpen
          ? 'bg-[hsl(var(--bg-canvas)/0.94)] backdrop-blur-md border-b border-[hsl(var(--border-subtle))]'
          : 'bg-gradient-to-b from-[hsl(var(--bg-deep)/0.85)] to-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 md:h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single line, no badges or subtitles) */}
        <a
          href="#inicio"
          className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-[hsl(var(--text-primary))] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
        >
          Galante Barbearia
        </a>

        {/* Zone 2: Clean single-line typography nav links */}
        <nav aria-label="Navegação principal" className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative text-sm font-medium text-[hsl(var(--text-secondary))] hover:text-[hsl(var(--text-primary))] transition-colors duration-200 whitespace-nowrap shrink-0 py-1 after:content-[''] after:absolute after:left-0 after:bottom-0 after:h-px after:w-0 after:bg-[hsl(var(--accent-gold))] hover:after:w-full after:transition-all after:duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-xs sm:text-sm font-semibold text-[hsl(var(--bg-deep))] bg-[hsl(var(--accent-gold))] hover:bg-[hsl(var(--accent-gold-bright))] transition-colors duration-200 whitespace-nowrap shrink-0 rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--bg-canvas))]"
          >
            Conversar no WhatsApp
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 text-[hsl(var(--text-primary))] hover:text-[hsl(var(--accent-gold))] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileOpen && (
        <div className="md:hidden bg-[hsl(var(--bg-canvas))] border-t border-[hsl(var(--border-subtle))] px-5 py-6">
          <nav aria-label="Menu mobile" className="flex flex-col gap-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="text-base font-medium text-[hsl(var(--text-secondary))] hover:text-[hsl(var(--accent-gold))] py-2 border-b border-[hsl(var(--border-subtle)/0.6)] transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="mt-2 inline-flex items-center justify-center min-h-[44px] px-5 py-3 text-sm font-semibold text-[hsl(var(--bg-deep))] bg-[hsl(var(--accent-gold))] hover:bg-[hsl(var(--accent-gold-bright))] transition-colors rounded-sm whitespace-nowrap"
            >
              Conversar no WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
