import { motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { SERVICES, buildWhatsAppUrl, type BarberService } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

interface ServicesSectionProps {
  onSelectService: (serviceName: string) => void;
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const shouldReduceMotion = useReducedMotion();
  const [featuredService, ...secondaryServices] = SERVICES;

  const handleBookClick = (service: BarberService) => {
    onSelectService(service.name);
    const contactEl = document.getElementById('contato');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: shouldReduceMotion ? 'auto' : 'smooth' });
    }
  };

  return (
    <section
      id="servicos"
      className="py-24 md:py-32 bg-[hsl(var(--bg-canvas))] border-b border-[hsl(var(--border-subtle))]"
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        {/* Section header — short title (<= 6 words), generous breath */}
        <motion.div
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 md:mb-20"
        >
          <div>
            <p className="text-xs font-medium tracking-[0.2em] text-[hsl(var(--accent-gold))] mb-3">
              Nossos Serviços
            </p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-[hsl(var(--text-primary))] leading-[1.1]">
              Ritual de corte e cuidado.
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[hsl(var(--text-secondary))] max-w-sm leading-relaxed">
            Atendimento sem pressa, técnica clássica e acabamento sob medida.
          </p>
        </motion.div>

        {/* Featured Row 1: Asymmetric 12-col split for Corte Masculino */}
        <motion.article
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch pb-16 md:pb-20 mb-16 md:mb-20 border-b border-[hsl(var(--border-subtle))]"
        >
          <div className="lg:col-span-7 overflow-hidden rounded-sm border border-[hsl(var(--border-subtle))]">
            <ResilientImage
              src={featuredService.image}
              alt={featuredService.imageAlt}
              aspectClassName="aspect-[4/3] lg:h-full"
              className="hover:scale-[1.02] transition-transform duration-500"
            />
          </div>

          <div className="lg:col-span-5 flex flex-col justify-between py-2">
            <div>
              <div className="flex items-center gap-3 text-xs font-medium text-[hsl(var(--text-muted))] mb-4 tabular-nums-data">
                <span className="text-[hsl(var(--accent-gold))]">{featuredService.index}.</span>
                <span aria-hidden="true">·</span>
                <span>{featuredService.duration}</span>
              </div>

              <div className="flex items-baseline justify-between gap-4 mb-5">
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-[hsl(var(--text-primary))]">
                  {featuredService.name}
                </h3>
                <span className="font-display text-2xl sm:text-3xl font-semibold text-[hsl(var(--accent-gold))] tabular-nums-data shrink-0">
                  {featuredService.price}
                </span>
              </div>

              <p className="text-base text-[hsl(var(--text-secondary))] leading-relaxed max-w-md">
                {featuredService.description}
              </p>
            </div>

            <div className="pt-8 mt-8 border-t border-[hsl(var(--border-subtle))] flex flex-wrap items-center gap-6">
              <a
                href={buildWhatsAppUrl(
                  `Olá! Gostaria de agendar o serviço ${featuredService.name} (${featuredService.price}) na Galante Barbearia.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 min-h-[44px] px-5 py-2.5 text-sm font-semibold text-[hsl(var(--bg-deep))] bg-[hsl(var(--accent-gold))] hover:bg-[hsl(var(--accent-gold-bright))] transition-colors duration-200 rounded-sm whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))]"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>

              <button
                type="button"
                onClick={() => handleBookClick(featuredService)}
                className="min-h-[44px] py-2 text-sm font-medium text-[hsl(var(--text-secondary))] hover:text-[hsl(var(--accent-gold))] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
              >
                Reservar no formulário
              </button>
            </div>
          </div>
        </motion.article>

        {/* Row 2: Asymmetric 2-column showcase for Barba & Tratamento Capilar */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12 items-start">
          {secondaryServices.map((service, idx) => (
            <motion.article
              key={service.id}
              initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.6, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className={
                idx === 0
                  ? 'md:col-span-6 flex flex-col'
                  : 'md:col-span-6 md:mt-12 flex flex-col'
              }
            >
              <div className="overflow-hidden rounded-sm border border-[hsl(var(--border-subtle))] mb-6">
                <ResilientImage
                  src={service.image}
                  alt={service.imageAlt}
                  aspectClassName="aspect-[4/3]"
                  className="hover:scale-[1.02] transition-transform duration-500"
                />
              </div>

              <div className="flex items-center gap-3 text-xs font-medium text-[hsl(var(--text-muted))] mb-2 tabular-nums-data">
                <span className="text-[hsl(var(--accent-gold))]">{service.index}.</span>
                <span aria-hidden="true">·</span>
                <span>{service.duration}</span>
              </div>

              <div className="flex items-baseline justify-between gap-4 mb-3">
                <h3 className="font-display text-2xl font-semibold text-[hsl(var(--text-primary))]">
                  {service.name}
                </h3>
                <span className="font-display text-2xl font-semibold text-[hsl(var(--accent-gold))] tabular-nums-data shrink-0">
                  {service.price}
                </span>
              </div>

              <p className="text-sm sm:text-base text-[hsl(var(--text-secondary))] leading-relaxed mb-6">
                {service.description}
              </p>

              <div className="pt-4 border-t border-[hsl(var(--border-subtle))] flex flex-wrap items-center gap-6">
                <a
                  href={buildWhatsAppUrl(
                    `Olá! Gostaria de agendar o serviço ${service.name} (${service.price}) na Galante Barbearia.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 min-h-[40px] text-sm font-semibold text-[hsl(var(--accent-gold))] hover:text-[hsl(var(--accent-gold-bright))] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
                >
                  <span>Agendar via WhatsApp</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                </a>

                <button
                  type="button"
                  onClick={() => handleBookClick(service)}
                  className="min-h-[40px] text-sm font-medium text-[hsl(var(--text-muted))] hover:text-[hsl(var(--text-primary))] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
                >
                  Selecionar serviço
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
