import { motion, useReducedMotion } from 'motion/react';
import { TRADITION_STATS } from '../data/barbershop';

export function AboutSection() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section
      id="sobre"
      className="py-24 md:py-32 bg-[hsl(var(--bg-deep))] border-b border-[hsl(var(--border-subtle))]"
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left editorial statement */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <p className="text-xs font-medium tracking-[0.2em] text-[hsl(var(--accent-gold))] mb-4">
              Sobre Nós
            </p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-[hsl(var(--text-primary))] leading-[1.12] mb-6">
              Tradição preservada em cada fio.
            </h2>
            <p className="text-base sm:text-lg text-[hsl(var(--text-secondary))] leading-relaxed max-w-xl">
              Na Galante Barbearia, cada atendimento une precisão técnica, hospitalidade e respeito
              ao tempo de quem valoriza um acabamento impecável.
            </p>
          </motion.div>

          {/* Right precision 2x2 hairline stats grid */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 grid grid-cols-2 border-t border-l border-[hsl(var(--border-subtle))]"
          >
            {TRADITION_STATS.map((stat) => (
              <div
                key={stat.label}
                className="p-6 sm:p-8 border-r border-b border-[hsl(var(--border-subtle))] bg-[hsl(var(--bg-canvas)/0.45)]"
              >
                <div className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold text-[hsl(var(--accent-gold))] tabular-nums-data mb-2">
                  {stat.value}
                </div>
                <p className="text-xs sm:text-sm text-[hsl(var(--text-secondary))] leading-snug">
                  {stat.label}
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
