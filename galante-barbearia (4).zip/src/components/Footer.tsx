import { ADDRESS_DISPLAY, PHONE_DISPLAY, buildWhatsAppUrl } from '../data/barbershop';

export function Footer() {
  const year = new Date().getFullYear();
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Galante Barbearia.'
  );

  return (
    <footer className="bg-[hsl(var(--bg-canvas))] border-t border-[hsl(var(--border-subtle))] py-12">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div>
          <a
            href="#inicio"
            className="font-display text-xl font-semibold text-[hsl(var(--text-primary))] tracking-tight"
          >
            Galante Barbearia
          </a>
          <p className="mt-2 text-xs sm:text-sm text-[hsl(var(--text-muted))]">
            {ADDRESS_DISPLAY}
          </p>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-6 text-sm text-[hsl(var(--text-secondary))]"
        >
          <a href="#inicio" className="hover:text-[hsl(var(--accent-gold))] transition-colors">
            Início
          </a>
          <a href="#servicos" className="hover:text-[hsl(var(--accent-gold))] transition-colors">
            Serviços
          </a>
          <a href="#sobre" className="hover:text-[hsl(var(--accent-gold))] transition-colors">
            Sobre Nós
          </a>
          <a href="#galeria" className="hover:text-[hsl(var(--accent-gold))] transition-colors">
            Galeria
          </a>
          <a href="#contato" className="hover:text-[hsl(var(--accent-gold))] transition-colors">
            Contato
          </a>
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[hsl(var(--accent-gold))] hover:text-[hsl(var(--accent-gold-bright))] transition-colors tabular-nums-data"
          >
            {PHONE_DISPLAY}
          </a>
        </nav>
      </div>

      <div className="max-w-6xl mx-auto px-5 sm:px-8 mt-8 pt-6 border-t border-[hsl(var(--border-subtle)/0.6)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[hsl(var(--text-muted))]">
        <span>© {year} Galante Barbearia. Todos os direitos reservados.</span>
        <span>Sumaré · São Paulo</span>
      </div>
    </footer>
  );
}
