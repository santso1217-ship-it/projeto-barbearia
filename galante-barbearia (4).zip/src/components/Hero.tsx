import { motion, useReducedMotion } from 'motion/react';
import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { HERO_IMAGE, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function Hero() {
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de agendar um horário na Galante Barbearia.'
  );

  return (
    <section
      id="inicio"
      className="relative min-h-[92svh] flex items-end pt-28 pb-16 sm:pb-24 overflow-hidden bg-[hsl(var(--bg-deep))]"
    >
      {/* Full-bleed architectural barbershop image */}
      <div className="absolute inset-0">
        <ResilientImage
          src={HERO_IMAGE}
          alt="Interior da Galante Barbearia com cadeiras clássicas, espelhos dourados e iluminação acolhedora"
          priority
          aspectClassName="w-full h-full"
          className="object-center scale-[1.01]"
        />
        {/* Measured scrims guaranteeing >= 4.5:1 contrast */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-[hsl(222_47%_11%)] via-[hsl(222_47%_11%/0.72)] to-[hsl(222_47%_11%/0.35)]"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-[hsl(222_47%_11%/0.92)] via-[hsl(222_47%_11%/0.55)] to-transparent"
        />
      </div>

      {/* Foreground editorial statement */}
      <div className="relative z-10 max-w-6xl mx-auto w-full px-5 sm:px-8">
        <motion.div
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl"
        >
          <p className="text-xs sm:text-sm font-medium tracking-[0.2em] text-[hsl(var(--accent-gold))] mb-5">
            Sumaré, São Paulo
          </p>

          {/* Single H1 on the page, luxury serif, responsive clamp */}
          <h1 className="font-display font-bold tracking-tight leading-[1.02] text-[clamp(2.85rem,7vw,5.5rem)] text-[hsl(var(--text-primary))] mb-6">
            Estilo &amp;{' '}
            <span className="text-gold-gradient italic font-semibold">Tradição</span>
          </h1>

          {/* Concise slogan (<= 8 words) */}
          <p className="text-lg sm:text-xl text-[hsl(var(--text-secondary))] font-normal max-w-xl leading-relaxed mb-10">
            Corte preciso. Presença impecável.
          </p>

          {/* Primary CTA + quiet scroll link */}
          <div className="flex flex-wrap items-center gap-6">
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-3 min-h-[48px] px-7 py-3.5 text-sm sm:text-base font-semibold text-[hsl(var(--bg-deep))] bg-[hsl(var(--accent-gold))] hover:bg-[hsl(var(--accent-gold-bright))] transition-colors duration-200 rounded-sm whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--bg-canvas))]"
            >
              <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Conversar no WhatsApp</span>
            </a>

            <a
              href="#contato"
              className="inline-flex items-center gap-2 min-h-[44px] py-2 text-sm sm:text-base font-medium text-[hsl(var(--text-primary))] hover:text-[hsl(var(--accent-gold))] transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] rounded-sm"
            >
              <span>Agendar horário</span>
              <ArrowDownRight className="w-4 h-4 text-[hsl(var(--accent-gold))]" aria-hidden="true" />
            </a>
          </div>
        </motion.div>
      </div>

      {/* Subtle hairline bottom edge inviting scroll */}
      <div
        aria-hidden="true"
        className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[hsl(var(--accent-gold)/0.4)] to-transparent"
      />
    </section>
  );
}
