import { motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { GALLERY_PORTRAIT_IMAGE, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

const CRAFT_PILLARS = [
  {
    number: '01',
    title: 'Visagismo Individual',
    detail: 'Proporções pensadas para o formato do rosto e a textura natural do cabelo.',
  },
  {
    number: '02',
    title: 'Toalha Quente & Navalha',
    detail: 'Preparo térmico da pele e lâmina de precisão para um barbear confortável.',
  },
  {
    number: '03',
    title: 'Ambiente Reservado',
    detail: 'Poltronas clássicas, iluminação quente e atendimento pontual no Centro de Sumaré.',
  },
];

export function GallerySection() {
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Vi o site da Galante Barbearia e gostaria de agendar um atendimento.'
  );

  return (
    <section
      id="galeria"
      className="py-24 md:py-32 bg-[hsl(var(--bg-canvas))] border-b border-[hsl(var(--border-subtle))]"
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Portrait image on left with subtle gold offset frame */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="relative">
              <div
                aria-hidden="true"
                className="hidden sm:block absolute -inset-3 translate-x-3 translate-y-3 border border-[hsl(var(--accent-gold)/0.35)] rounded-sm pointer-events-none"
              />
              <div className="relative overflow-hidden rounded-sm border border-[hsl(var(--border-subtle))]">
                <ResilientImage
                  src={GALLERY_PORTRAIT_IMAGE}
                  alt="Barbeiro especialista da Galante Barbearia com tesoura ao lado de cadeira clássica"
                  aspectClassName="aspect-[3/4]"
                />
              </div>
            </div>
          </motion.div>

          {/* Editorial craft details on right */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <p className="text-xs font-medium tracking-[0.2em] text-[hsl(var(--accent-gold))] mb-4">
              Galeria &amp; Ofício
            </p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-[hsl(var(--text-primary))] leading-[1.12] mb-10">
              A arte de cuidar do próprio estilo.
            </h2>

            <div className="divide-y divide-[hsl(var(--border-subtle))] border-y border-[hsl(var(--border-subtle))] mb-10">
              {CRAFT_PILLARS.map((item) => (
                <div
                  key={item.number}
                  className="py-6 grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-6 items-baseline"
                >
                  <div className="sm:col-span-4 flex items-baseline gap-3">
                    <span className="text-xs font-medium text-[hsl(var(--accent-gold))] tabular-nums-data">
                      {item.number}.
                    </span>
                    <h3 className="font-display text-lg sm:text-xl font-semibold text-[hsl(var(--text-primary))]">
                      {item.title}
                    </h3>
                  </div>
                  <p className="sm:col-span-8 text-sm sm:text-base text-[hsl(var(--text-secondary))] leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              ))}
            </div>

            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 min-h-[44px] px-6 py-3 text-sm font-semibold text-[hsl(var(--accent-gold))] border border-[hsl(var(--accent-gold)/0.6)] hover:bg-[hsl(var(--accent-gold))] hover:text-[hsl(var(--bg-deep))] transition-colors duration-200 rounded-sm whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))]"
            >
              <span>Conversar no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
