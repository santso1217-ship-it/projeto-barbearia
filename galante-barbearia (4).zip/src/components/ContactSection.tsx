import { useState, useEffect, type FormEvent } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MapPin, Phone, Clock, CheckCircle2, MessageCircle } from 'lucide-react';
import {
  ADDRESS_DISPLAY,
  PHONE_DISPLAY,
  SERVICES,
  buildWhatsAppUrl,
} from '../data/barbershop';

interface ContactSectionProps {
  selectedService: string;
  onServiceChange: (serviceName: string) => void;
}

interface FormErrors {
  name?: string;
  phone?: string;
}

export function ContactSection({
  selectedService,
  onServiceChange,
}: ContactSectionProps) {
  const shouldReduceMotion = useReducedMotion();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [period, setPeriod] = useState('Manhã');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedService && SERVICES[0]) {
      onServiceChange(SERVICES[0].name);
    }
  }, [selectedService, onServiceChange]);

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};
    const trimmedName = name.trim();
    const digitsOnly = phone.replace(/\D/g, '');

    if (trimmedName.length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    if (digitsOnly.length < 10) {
      nextErrors.phone = 'Informe um telefone ou WhatsApp válido com DDD.';
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validate()) return;

    const chosenService = selectedService || SERVICES[0].name;
    const messageLines = [
      `Olá, Galante Barbearia! Gostaria de agendar um horário.`,
      `• Nome: ${name.trim()}`,
      `• WhatsApp: ${phone.trim()}`,
      `• Serviço: ${chosenService}`,
      `• Preferência de período: ${period}`,
    ];
    if (notes.trim()) {
      messageLines.push(`• Observação: ${notes.trim()}`);
    }

    const url = buildWhatsAppUrl(messageLines.join('\n'));
    setSubmittedUrl(url);
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const directWhatsApp = buildWhatsAppUrl(
    'Olá! Gostaria de conversar sobre horários na Galante Barbearia.'
  );

  return (
    <section
      id="contato"
      className="py-24 md:py-32 bg-[hsl(var(--bg-deep))]"
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left column: Contact details */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs font-medium tracking-[0.2em] text-[hsl(var(--accent-gold))] mb-4">
              Contato &amp; Localização
            </p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-[hsl(var(--text-primary))] leading-[1.12] mb-6">
              Reserve sua cadeira.
            </h2>
            <p className="text-base text-[hsl(var(--text-secondary))] leading-relaxed mb-10 max-w-md">
              Agende diretamente pelo formulário ou fale conosco pelo WhatsApp para confirmar o melhor horário.
            </p>

            <div className="space-y-6 border-t border-[hsl(var(--border-subtle))] pt-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-[hsl(var(--accent-gold))] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs font-medium text-[hsl(var(--text-muted))] mb-1">
                    Endereço
                  </p>
                  <p className="text-sm sm:text-base text-[hsl(var(--text-primary))] leading-relaxed">
                    {ADDRESS_DISPLAY}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-[hsl(var(--accent-gold))] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs font-medium text-[hsl(var(--text-muted))] mb-1">
                    Telefone &amp; WhatsApp
                  </p>
                  <a
                    href={directWhatsApp}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm sm:text-base font-medium text-[hsl(var(--text-primary))] hover:text-[hsl(var(--accent-gold))] transition-colors tabular-nums-data"
                  >
                    {PHONE_DISPLAY}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="w-5 h-5 text-[hsl(var(--accent-gold))] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs font-medium text-[hsl(var(--text-muted))] mb-1">
                    Atendimento
                  </p>
                  <p className="text-sm sm:text-base text-[hsl(var(--text-secondary))]">
                    Horários disponíveis sob consulta via WhatsApp.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right column: Online Booking Form */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-[hsl(var(--bg-canvas))] border border-[hsl(var(--border-subtle))] rounded-sm p-6 sm:p-10"
          >
            <div className="mb-8">
              <h3 className="font-display text-2xl font-semibold text-[hsl(var(--text-primary))] mb-2">
                Agendamento Online
              </h3>
              <p className="text-sm text-[hsl(var(--text-muted))]">
                Preencha os dados para iniciar o atendimento imediato no WhatsApp.
              </p>
            </div>

            <form onSubmit={handleSubmit} noValidate className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label
                    htmlFor="booking-name"
                    className="block text-xs font-medium text-[hsl(var(--text-secondary))] mb-2"
                  >
                    Seu nome *
                  </label>
                  <input
                    id="booking-name"
                    name="name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder="Ex.: Rafael Almeida"
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'booking-name-error' : undefined}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm text-[hsl(var(--text-primary))] bg-[hsl(var(--bg-deep))] border border-[hsl(var(--border-subtle))] rounded-sm placeholder:text-[hsl(var(--text-muted))] focus:outline-none focus:border-[hsl(var(--accent-gold))] transition-colors"
                  />
                  {errors.name && (
                    <p id="booking-name-error" className="mt-1.5 text-xs text-amber-400">
                      {errors.name}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="booking-phone"
                    className="block text-xs font-medium text-[hsl(var(--text-secondary))] mb-2"
                  >
                    WhatsApp com DDD *
                  </label>
                  <input
                    id="booking-phone"
                    name="phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                    }}
                    placeholder="(19) 99999-9999"
                    aria-invalid={Boolean(errors.phone)}
                    aria-describedby={errors.phone ? 'booking-phone-error' : undefined}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm text-[hsl(var(--text-primary))] bg-[hsl(var(--bg-deep))] border border-[hsl(var(--border-subtle))] rounded-sm placeholder:text-[hsl(var(--text-muted))] focus:outline-none focus:border-[hsl(var(--accent-gold))] transition-colors tabular-nums-data"
                  />
                  {errors.phone && (
                    <p id="booking-phone-error" className="mt-1.5 text-xs text-amber-400">
                      {errors.phone}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label
                    htmlFor="booking-service"
                    className="block text-xs font-medium text-[hsl(var(--text-secondary))] mb-2"
                  >
                    Serviço desejado
                  </label>
                  <select
                    id="booking-service"
                    name="service"
                    value={selectedService}
                    onChange={(e) => onServiceChange(e.target.value)}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm text-[hsl(var(--text-primary))] bg-[hsl(var(--bg-deep))] border border-[hsl(var(--border-subtle))] rounded-sm focus:outline-none focus:border-[hsl(var(--accent-gold))] transition-colors"
                  >
                    {SERVICES.map((service) => (
                      <option key={service.id} value={service.name}>
                        {service.name} ({service.price})
                      </option>
                    ))}
                    <option value="Corte + Barba">Corte + Barba</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="booking-period"
                    className="block text-xs font-medium text-[hsl(var(--text-secondary))] mb-2"
                  >
                    Preferência de período
                  </label>
                  <select
                    id="booking-period"
                    name="period"
                    value={period}
                    onChange={(e) => setPeriod(e.target.value)}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm text-[hsl(var(--text-primary))] bg-[hsl(var(--bg-deep))] border border-[hsl(var(--border-subtle))] rounded-sm focus:outline-none focus:border-[hsl(var(--accent-gold))] transition-colors"
                  >
                    <option value="Manhã">Manhã</option>
                    <option value="Tarde">Tarde</option>
                    <option value="Final da tarde">Final da tarde</option>
                    <option value="Qualquer horário disponível">Qualquer horário disponível</option>
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="booking-notes"
                  className="block text-xs font-medium text-[hsl(var(--text-secondary))] mb-2"
                >
                  Observações (opcional)
                </label>
                <textarea
                  id="booking-notes"
                  name="notes"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Dia preferido ou preferência de barbeiro..."
                  className="w-full px-4 py-3 text-sm text-[hsl(var(--text-primary))] bg-[hsl(var(--bg-deep))] border border-[hsl(var(--border-subtle))] rounded-sm placeholder:text-[hsl(var(--text-muted))] focus:outline-none focus:border-[hsl(var(--accent-gold))] transition-colors resize-none"
                />
              </div>

              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2.5 min-h-[48px] px-7 py-3 text-sm font-semibold text-[hsl(var(--bg-deep))] bg-[hsl(var(--accent-gold))] hover:bg-[hsl(var(--accent-gold-bright))] transition-colors duration-200 rounded-sm whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--accent-gold))] focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--bg-canvas))]"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Conversar no WhatsApp</span>
                </button>

                <span className="text-xs text-[hsl(var(--text-muted))]">
                  Resposta direta com nossa recepção.
                </span>
              </div>

              {submittedUrl && (
                <div
                  role="status"
                  className="mt-4 p-4 border border-[hsl(var(--accent-gold)/0.4)] bg-[hsl(var(--accent-gold)/0.08)] rounded-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 text-sm text-[hsl(var(--text-primary))]">
                    <CheckCircle2 className="w-4 h-4 text-[hsl(var(--accent-gold))] shrink-0" aria-hidden="true" />
                    <span>Solicitação pronta para envio no WhatsApp.</span>
                  </div>
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-semibold text-[hsl(var(--accent-gold))] underline underline-offset-4 whitespace-nowrap shrink-0"
                  >
                    Abrir conversa novamente
                  </a>
                </div>
              )}
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
