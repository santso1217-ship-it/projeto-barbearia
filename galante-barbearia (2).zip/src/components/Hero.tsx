import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { BARBERSHOP_INFO, buildWhatsAppUrl } from '../data/barbershop';
import { ImageWithFallback } from './ImageWithFallback';

interface HeroProps {
  onOpenBooking: () => void;
}

export function Hero({ onOpenBooking }: HeroProps) {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de agendar um horário na Galante Barbearia.'
  );

  return (
    <section
      id="inicio"
      className="relative overflow-hidden bg-canvas pt-10 pb-14 sm:pt-14 sm:pb-20 lg:pt-16 lg:pb-24"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col items-start"
          >
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-gold mb-5">
              Centro, Sumaré · SP
            </p>

            <h1 className="font-display font-semibold tracking-tight leading-[1.02] [text-wrap:balance] text-[clamp(3rem,6vw,5.25rem)] bg-gradient-to-br from-ink via-ink to-gold bg-clip-text text-transparent mb-6">
              {BARBERSHOP_INFO.headline}
            </h1>

            <p className="text-base sm:text-lg text-ink-muted leading-relaxed max-w-md mb-10">
              {BARBERSHOP_INFO.subheadline}
            </p>

            <div className="flex flex-wrap items-center gap-6">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-2.5 px-7 py-4 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-2"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight
                  className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  aria-hidden="true"
                />
              </a>

              <button
                type="button"
                onClick={onOpenBooking}
                className="py-2 text-sm font-medium text-ink-muted hover:text-gold transition-colors duration-150 underline underline-offset-8 decoration-line hover:decoration-gold whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
              >
                Agendar horário online
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full overflow-hidden rounded-sm border border-line bg-surface">
              <ImageWithFallback
                src={BARBERSHOP_INFO.heroImage}
                alt={BARBERSHOP_INFO.heroImageAlt}
                loading="eager"
                fetchPriority="high"
                className="w-full h-full object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/80 via-canvas/15 to-transparent"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
