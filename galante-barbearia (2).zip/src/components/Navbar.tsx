import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { BARBERSHOP_INFO } from '../data/barbershop';

interface NavbarProps {
  onOpenBooking: () => void;
}

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#sobre', label: 'A Casa' },
  { href: '#contato', label: 'Contato' },
];

export function Navbar({ onOpenBooking }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-canvas/90 backdrop-blur-md border-b border-line">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between gap-8">
        <a
          href="#inicio"
          className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-ink whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
        >
          {BARBERSHOP_INFO.name}
        </a>

        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-8 text-sm font-medium text-ink-muted"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative py-1 whitespace-nowrap shrink-0 hover:text-ink transition-colors duration-150 after:content-[''] after:absolute after:left-0 after:bottom-0 after:h-px after:w-0 after:bg-gold after:transition-all after:duration-200 hover:after:w-full focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenBooking}
            className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-xs font-semibold tracking-wide text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-2"
          >
            Agendar Horário
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 text-ink hover:text-gold transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-gold"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" aria-hidden="true" />
            ) : (
              <Menu className="w-5 h-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <nav
          aria-label="Menu móvel"
          className="md:hidden bg-canvas-deep border-b border-line px-5 py-5 flex flex-col gap-3"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className="py-2.5 text-base font-medium text-ink-muted hover:text-gold transition-colors border-b border-line/50 last:border-b-0"
            >
              {item.label}
            </a>
          ))}
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenBooking();
            }}
            className="mt-2 w-full py-3 px-5 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors cursor-pointer"
          >
            Agendar Horário
          </button>
        </nav>
      )}
    </header>
  );
}
