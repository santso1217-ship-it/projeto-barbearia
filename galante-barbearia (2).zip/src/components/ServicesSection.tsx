import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { SERVICES, type ServiceItem } from '../data/barbershop';
import { ImageWithFallback } from './ImageWithFallback';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const [featured, second, third] = SERVICES;

  return (
    <section
      id="servicos"
      className="bg-canvas border-t border-line py-24 sm:py-28 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14 lg:mb-16"
        >
          <div>
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-gold mb-3">
              Nossos Serviços
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink [text-wrap:balance]">
              Precisão em cada detalhe
            </h2>
          </div>
          <p className="text-sm sm:text-base text-ink-muted max-w-sm leading-relaxed">
            Técnica clássica e acabamento contemporâneo pensados para o seu ritmo.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Featured Vertical Service */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-between bg-surface border border-line rounded-sm overflow-hidden group"
          >
            <div className="relative aspect-[4/3] sm:aspect-[16/11] lg:aspect-[5/4] w-full overflow-hidden">
              <ImageWithFallback
                src={featured.image}
                alt={featured.imageAlt}
                className="w-full h-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-[1.03]"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent"
              />
            </div>

            <div className="p-6 sm:p-8 flex flex-col flex-1 justify-between gap-6">
              <div>
                <div className="flex items-baseline justify-between gap-4 mb-3">
                  <h3 className="font-display text-2xl sm:text-3xl font-semibold text-ink">
                    <span className="text-gold mr-2 font-normal">
                      {featured.index}
                    </span>
                    {featured.name}
                  </h3>
                  <span className="font-display text-2xl sm:text-3xl font-semibold text-gold tabular-nums whitespace-nowrap shrink-0">
                    {featured.price}
                  </span>
                </div>
                <p className="text-sm sm:text-base text-ink-muted leading-relaxed max-w-prose">
                  {featured.description}
                </p>
              </div>

              <div className="pt-4 border-t border-line flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onSelectService(featured)}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-gold hover:text-gold-hover transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
                >
                  <span>{featured.ctaLabel}</span>
                  <ArrowRight
                    className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-1"
                    aria-hidden="true"
                  />
                </button>
              </div>
            </div>
          </motion.article>

          {/* Stacked Asymmetric Horizontal Services */}
          <div className="lg:col-span-6 flex flex-col gap-8 lg:gap-10">
            {[second, third].map((service, idx) => (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.6,
                  delay: idx * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="flex-1 grid grid-cols-1 sm:grid-cols-12 bg-surface border border-line rounded-sm overflow-hidden group"
              >
                <div
                  className={`sm:col-span-5 relative aspect-[4/3] sm:aspect-auto min-h-[210px] overflow-hidden ${
                    idx === 1 ? 'sm:order-2' : ''
                  }`}
                >
                  <ImageWithFallback
                    src={service.image}
                    alt={service.imageAlt}
                    className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                  />
                </div>

                <div
                  className={`sm:col-span-7 p-6 sm:p-7 flex flex-col justify-between gap-5 ${
                    idx === 1 ? 'sm:order-1' : ''
                  }`}
                >
                  <div>
                    <div className="flex items-baseline justify-between gap-3 mb-2.5">
                      <h3 className="font-display text-xl sm:text-2xl font-semibold text-ink">
                        <span className="text-gold mr-2 font-normal">
                          {service.index}
                        </span>
                        {service.name}
                      </h3>
                      <span className="font-display text-xl sm:text-2xl font-semibold text-gold tabular-nums whitespace-nowrap shrink-0">
                        {service.price}
                      </span>
                    </div>
                    <p className="text-sm text-ink-muted leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-line">
                    <button
                      type="button"
                      onClick={() => onSelectService(service)}
                      className="inline-flex items-center gap-2 text-sm font-semibold text-gold hover:text-gold-hover transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
                    >
                      <span>{service.ctaLabel}</span>
                      <ArrowRight
                        className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </button>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
