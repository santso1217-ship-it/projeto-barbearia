import { useState, type FormEvent } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, CheckCircle2, MapPin, Phone } from 'lucide-react';
import {
  BARBERSHOP_INFO,
  SERVICES,
  buildWhatsAppUrl,
} from '../data/barbershop';

export function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState(SERVICES[0].name);
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const directWhatsAppUrl = buildWhatsAppUrl(
    'Olá! Gostaria de conversar e agendar um horário na Galante Barbearia.'
  );

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const trimmedName = name.trim();
    const cleanPhone = phone.replace(/\D/g, '');

    if (trimmedName.length < 2) {
      setError('Informe seu nome para continuar.');
      return;
    }

    if (cleanPhone.length < 10) {
      setError('Informe um número de WhatsApp válido com DDD.');
      return;
    }

    setError(null);
    const composedMessage = [
      `Olá, Galante Barbearia! Meu nome é ${trimmedName}.`,
      `WhatsApp para retorno: ${phone.trim()}`,
      `Serviço de interesse: ${service}`,
      message.trim() ? `Observação: ${message.trim()}` : null,
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedUrl(buildWhatsAppUrl(composedMessage));
  }

  return (
    <section
      id="contato"
      className="bg-canvas border-t border-line py-24 sm:py-28 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-gold mb-4">
              Contato
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink [text-wrap:balance] mb-6">
              Sua cadeira em Sumaré
            </h2>
            <p className="text-base text-ink-muted leading-relaxed mb-10 max-w-md">
              Atendimento mediante agendamento prévio. Fale diretamente com nossa
              recepção pelo WhatsApp.
            </p>

            <div className="space-y-6 border-t border-line pt-8 mb-10">
              <div className="flex items-start gap-4">
                <MapPin
                  className="w-5 h-5 text-gold shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs uppercase tracking-[0.14em] text-ink-muted mb-1">
                    Endereço
                  </p>
                  <p className="text-base text-ink leading-snug">
                    {BARBERSHOP_INFO.address}
                  </p>
                  <a
                    href={BARBERSHOP_INFO.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 mt-2 text-xs font-semibold text-gold hover:text-gold-hover underline underline-offset-4"
                  >
                    <span>Abrir no mapa</span>
                    <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone
                  className="w-5 h-5 text-gold shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs uppercase tracking-[0.14em] text-ink-muted mb-1">
                    WhatsApp & Telefone
                  </p>
                  <a
                    href={directWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-base text-ink hover:text-gold transition-colors tabular-nums"
                  >
                    {BARBERSHOP_INFO.phoneDisplay}
                  </a>
                </div>
              </div>
            </div>

            <a
              href={directWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2.5 px-7 py-4 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-2"
            >
              <span>Conversar no WhatsApp</span>
              <ArrowUpRight
                className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                aria-hidden="true"
              />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-surface border border-line rounded-sm p-6 sm:p-10"
          >
            <h3 className="font-display text-2xl font-semibold text-ink mb-2">
              Solicitar horário
            </h3>
            <p className="text-sm text-ink-muted mb-8">
              Preencha seus dados para iniciar a conversa já com o serviço
              selecionado.
            </p>

            {submittedUrl ? (
              <div className="border border-gold/40 bg-canvas-deep rounded-sm p-6 sm:p-8 space-y-5">
                <div className="flex items-start gap-3">
                  <CheckCircle2
                    className="w-5 h-5 text-gold shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="font-display text-xl font-semibold text-ink">
                      Solicitação pronta para envio
                    </p>
                    <p className="text-sm text-ink-muted mt-1">
                      Clique abaixo para confirmar seu horário diretamente no
                      WhatsApp da Galante Barbearia.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors"
                  >
                    <span>Conversar no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                  </a>
                  <button
                    type="button"
                    onClick={() => setSubmittedUrl(null)}
                    className="px-4 py-3 text-sm font-medium text-ink-muted hover:text-ink transition-colors cursor-pointer"
                  >
                    Editar dados
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
                    >
                      Nome completo
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Seu nome"
                      className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink placeholder:text-ink-muted/50 focus:outline-none focus:border-gold transition-colors"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="contact-phone"
                      className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
                    >
                      WhatsApp
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(19) 99999-9999"
                      className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink placeholder:text-ink-muted/50 focus:outline-none focus:border-gold transition-colors tabular-nums"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contact-service"
                    className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
                  >
                    Serviço
                  </label>
                  <select
                    id="contact-service"
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink focus:outline-none focus:border-gold transition-colors"
                  >
                    {SERVICES.map((item) => (
                      <option key={item.id} value={item.name}>
                        {item.name} — {item.price}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
                  >
                    Preferência de dia ou observação
                  </label>
                  <textarea
                    id="contact-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Ex.: Sexta-feira no fim da tarde"
                    className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink placeholder:text-ink-muted/50 focus:outline-none focus:border-gold transition-colors resize-none"
                  />
                </div>

                {error && (
                  <p role="alert" className="text-sm text-gold font-medium">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 px-7 py-4 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-2"
                >
                  <span>Continuar para o WhatsApp</span>
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
