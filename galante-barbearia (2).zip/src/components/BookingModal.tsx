import { useEffect, useState } from 'react';
import { ArrowUpRight, X } from 'lucide-react';
import {
  SERVICES,
  buildWhatsAppUrl,
  type ServiceItem,
} from '../data/barbershop';

interface BookingModalProps {
  isOpen: boolean;
  initialService: ServiceItem | null;
  onClose: () => void;
}

const PERIODS = ['Manhã', 'Tarde', 'Noite'] as const;

export function BookingModal({
  isOpen,
  initialService,
  onClose,
}: BookingModalProps) {
  const [selectedServiceId, setSelectedServiceId] = useState<ServiceItem['id']>(
    initialService?.id ?? 'corte'
  );
  const [clientName, setClientName] = useState('');
  const [date, setDate] = useState('');
  const [period, setPeriod] = useState<(typeof PERIODS)[number]>('Tarde');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialService) {
      setSelectedServiceId(initialService.id);
    }
  }, [initialService]);

  useEffect(() => {
    if (!isOpen) return;
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const selectedService =
    SERVICES.find((s) => s.id === selectedServiceId) ?? SERVICES[0];

  const todayIso = new Date().toISOString().split('T')[0];

  const formattedDate = date
    ? new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      })
    : 'A combinar';

  const canSendDirectly = clientName.trim().length >= 2;

  const bookingMessage = [
    `Olá, Galante Barbearia! Gostaria de agendar um horário:`,
    `• Cliente: ${clientName.trim()}`,
    `• Serviço: ${selectedService.name} (${selectedService.price})`,
    `• Data: ${formattedDate}`,
    `• Período: ${period}`,
  ].join('\n');

  const whatsappUrl = buildWhatsAppUrl(bookingMessage);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-canvas-deep/85 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg bg-surface border border-line rounded-sm p-6 sm:p-8 shadow-2xl">
        <div className="flex items-start justify-between gap-4 pb-5 border-b border-line">
          <div>
            <p className="text-xs font-medium tracking-[0.16em] uppercase text-gold mb-1">
              Agendamento Online
            </p>
            <h2
              id="booking-modal-title"
              className="font-display text-2xl font-semibold text-ink"
            >
              Reserve sua cadeira
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela de agendamento"
            className="w-10 h-10 inline-flex items-center justify-center text-ink-muted hover:text-ink transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-6 space-y-6">
          <div>
            <span className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2.5">
              Escolha o serviço
            </span>
            <div className="grid grid-cols-1 gap-2.5">
              {SERVICES.map((item) => {
                const isSelected = item.id === selectedServiceId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedServiceId(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 text-left rounded-sm border transition-colors duration-150 cursor-pointer ${
                      isSelected
                        ? 'bg-canvas border-gold text-ink'
                        : 'bg-canvas/50 border-line text-ink-muted hover:border-ink-muted/50 hover:text-ink'
                    }`}
                  >
                    <span className="text-sm font-medium">{item.name}</span>
                    <span className="text-sm font-semibold text-gold tabular-nums">
                      {item.price}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="booking-name"
                className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
              >
                Seu nome
              </label>
              <input
                id="booking-name"
                type="text"
                value={clientName}
                onChange={(e) => {
                  setClientName(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Nome completo"
                className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink placeholder:text-ink-muted/50 focus:outline-none focus:border-gold transition-colors"
              />
            </div>

            <div>
              <label
                htmlFor="booking-date"
                className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2"
              >
                Data preferida
              </label>
              <input
                id="booking-date"
                type="date"
                min={todayIso}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-4 py-3 text-sm bg-canvas border border-line rounded-sm text-ink focus:outline-none focus:border-gold transition-colors tabular-nums"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium uppercase tracking-[0.12em] text-ink-muted mb-2.5">
              Período de preferência
            </span>
            <div className="grid grid-cols-3 gap-2 p-1 bg-canvas border border-line rounded-sm">
              {PERIODS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPeriod(p)}
                  className={`py-2 text-xs font-semibold rounded-sm transition-colors duration-150 cursor-pointer ${
                    period === p
                      ? 'bg-gold text-canvas'
                      : 'text-ink-muted hover:text-ink'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <p role="alert" className="text-sm text-gold font-medium">
              {error}
            </p>
          )}

          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-t border-line">
            <div className="text-xs text-ink-muted">
              Valor estimado:{' '}
              <span className="text-sm font-semibold text-gold tabular-nums">
                {selectedService.price}
              </span>
            </div>

            {canSendDirectly ? (
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={onClose}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors whitespace-nowrap shrink-0"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
              </a>
            ) : (
              <button
                type="button"
                onClick={() => setError('Digite seu nome para agendar no WhatsApp.')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-canvas bg-gold hover:bg-gold-hover rounded-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
