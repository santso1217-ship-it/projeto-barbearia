import { motion } from 'motion/react';
import { BARBERSHOP_INFO, HERITAGE_STATS } from '../data/barbershop';
import { ImageWithFallback } from './ImageWithFallback';

export function AboutSection() {
  return (
    <section
      id="sobre"
      className="bg-canvas-deep border-t border-line py-24 sm:py-28 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-stretch">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-gold mb-4">
              A Casa
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink [text-wrap:balance] mb-8">
              Tradição que se vê no detalhe
            </h2>

            <div className="space-y-5 text-base sm:text-lg text-ink-muted leading-relaxed max-w-xl">
              <p>
                Na Galante Barbearia, cada atendimento respeita o tempo certo da
                tesoura, da navalha bem afiada e da conversa tranquila. Unimos a
                escola clássica da barbearia à leitura moderna de visagismo.
              </p>
              <p>
                Nossa equipe reúne mestres dedicados ao caimento natural, ao
                conforto da toalha quente e à excelência de quem entende que
                cuidar da aparência é um ritual diário de presença.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex justify-center lg:justify-end"
          >
            <div className="w-full max-w-md lg:max-w-none aspect-[4/5] overflow-hidden rounded-t-full border border-line bg-surface">
              <ImageWithFallback
                src={BARBERSHOP_INFO.aboutImage}
                alt={BARBERSHOP_INFO.aboutImageAlt}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* Adjacent Heritage Proof Strip */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
          className="mt-16 lg:mt-20 pt-10 border-t border-line grid grid-cols-2 lg:grid-cols-4 gap-y-8 lg:gap-y-0 lg:divide-x lg:divide-line"
        >
          {HERITAGE_STATS.map((stat) => (
            <div
              key={stat.label}
              className="lg:px-8 first:lg:pl-0 last:lg:pr-0 flex flex-col gap-1.5"
            >
              <span className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-gold tabular-nums tracking-tight">
                {stat.value}
              </span>
              <span className="text-sm text-ink-muted">{stat.label}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
