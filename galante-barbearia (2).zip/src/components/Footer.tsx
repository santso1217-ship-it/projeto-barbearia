import { BARBERSHOP_INFO, buildWhatsAppUrl } from '../data/barbershop';

export function Footer() {
  const whatsappUrl = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Galante Barbearia.'
  );

  return (
    <footer className="bg-canvas-deep border-t border-line py-12">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div>
          <a
            href="#inicio"
            className="font-display text-xl font-semibold text-ink tracking-tight"
          >
            {BARBERSHOP_INFO.name}
          </a>
          <p className="text-xs text-ink-muted mt-2">
            {BARBERSHOP_INFO.address}
          </p>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-ink-muted"
        >
          <a href="#inicio" className="hover:text-gold transition-colors">
            Início
          </a>
          <a href="#servicos" className="hover:text-gold transition-colors">
            Serviços
          </a>
          <a href="#sobre" className="hover:text-gold transition-colors">
            A Casa
          </a>
          <a href="#contato" className="hover:text-gold transition-colors">
            Contato
          </a>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gold hover:text-gold-hover transition-colors"
          >
            WhatsApp
          </a>
        </nav>

        <p className="text-xs text-ink-muted">
          © 2026 {BARBERSHOP_INFO.name}
        </p>
      </div>
    </footer>
  );
}
