import heroBarbeariaImg from '../assets/images/hero_barbearia_galante_1794578778694.jpg';
import sobreAmbienteImg from '../assets/images/sobre_ambiente_barbearia_1794578780291.jpg';
import servicoCorteImg from '../assets/images/servico_corte_masculino_1794578779978.jpg';
import servicoBarbaImg from '../assets/images/servico_barba_navalha_1794578779789.jpg';
import servicoTratamentoImg from '../assets/images/servico_tratamento_capilar_1794578780055.jpg';

export interface ServiceItem {
  id: 'corte' | 'barba' | 'tratamento';
  index: string;
  name: string;
  price: string;
  priceNumeric: number;
  description: string;
  image: string;
  imageAlt: string;
  ctaLabel: string;
}

export interface HeritageStat {
  value: string;
  label: string;
}

export const BARBERSHOP_INFO = {
  name: 'Galante Barbearia',
  headline: 'Estilo & Tradição',
  subheadline:
    'Corte de precisão, navalha quente e cuidado masculino no Centro de Sumaré.',
  address: 'R. Ângelo Ôngaro, 300 - Centro, Sumaré - SP, 13170-024',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=R.+%C3%82ngelo+%C3%94ngaro,+300+-+Centro,+Sumar%C3%A9+-+SP,+13170-024',
  phoneDisplay: '+55 19 98406-4616',
  whatsappDigits: '5519984064616',
  heroImage: heroBarbeariaImg,
  heroImageAlt:
    'Interior sofisticado da Galante Barbearia com cadeiras clássicas, espelhos em arco dourado e iluminação quente',
  aboutImage: sobreAmbienteImg,
  aboutImageAlt:
    'Instrumentos tradicionais de barbearia em aço e latão sobre bancada de ardósia e madeira nobre',
} as const;

export const SERVICES: ServiceItem[] = [
  {
    id: 'corte',
    index: '01.',
    name: 'Corte Masculino',
    price: 'R$ 60',
    priceNumeric: 60,
    description:
      'Diagnóstico do caimento, corte na tesoura e máquina com acabamento na navalha e lavagem relaxante.',
    image: servicoCorteImg,
    imageAlt:
      'Barbeiro realizando corte masculino de precisão com tesoura e pente na Galante Barbearia',
    ctaLabel: 'Agendar corte',
  },
  {
    id: 'barba',
    index: '02.',
    name: 'Barba',
    price: 'R$ 45',
    priceNumeric: 45,
    description:
      'Ritual clássico com toalha quente, alinhamento simétrico na navalha e bálsamo pós-barba hidratante.',
    image: servicoBarbaImg,
    imageAlt:
      'Barbeiro modelando barba com navalha clássica em ambiente elegante de barbearia',
    ctaLabel: 'Agendar barba',
  },
  {
    id: 'tratamento',
    index: '03.',
    name: 'Tratamento Capilar',
    price: 'R$ 80',
    priceNumeric: 80,
    description:
      'Limpeza profunda do couro cabeludo, nutrição botânica e massagem craniana para vitalidade dos fios.',
    image: servicoTratamentoImg,
    imageAlt:
      'Atendimento de tratamento capilar e massagem relaxante no lavatório da barbearia',
    ctaLabel: 'Agendar tratamento',
  },
];

export const HERITAGE_STATS: HeritageStat[] = [
  { value: '15+', label: 'Anos de experiência' },
  { value: '10.000+', label: 'Clientes atendidos' },
  { value: '5', label: 'Barbeiros especialistas' },
  { value: '4,9', label: 'Nota de avaliação' },
];

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMessage =
    'Olá! Gostaria de conversar e agendar um horário na Galante Barbearia.';
  const text = encodeURIComponent(customMessage || defaultMessage);
  return `https://wa.me/${BARBERSHOP_INFO.whatsappDigits}?text=${text}`;
}
