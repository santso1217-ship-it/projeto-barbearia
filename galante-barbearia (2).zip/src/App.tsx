/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { type ServiceItem } from './data/barbershop';

export default function App() {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(
    null
  );

  function handleOpenBooking(service: ServiceItem | null = null) {
    setSelectedService(service);
    setBookingOpen(true);
  }

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-canvas text-ink">
        <Navbar onOpenBooking={() => handleOpenBooking(null)} />
        <main className="flex-1">
          <Hero onOpenBooking={() => handleOpenBooking(null)} />
          <ServicesSection
            onSelectService={(service) => handleOpenBooking(service)}
          />
          <AboutSection />
          <ContactSection />
        </main>
        <Footer />
        <BookingModal
          isOpen={bookingOpen}
          initialService={selectedService}
          onClose={() => setBookingOpen(false)}
        />
      </div>
    </MotionConfig>
  );
}
