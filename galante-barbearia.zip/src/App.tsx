/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { AboutGallerySection } from './components/AboutGallerySection';
import { ContactBookingSection } from './components/ContactBookingSection';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { Navbar } from './components/Navbar';
import { ServicesSection } from './components/ServicesSection';
import type { ServiceItem } from './data/barbershop';

export default function App() {
  const [selectedServiceId, setSelectedServiceId] = useState<ServiceItem['id']>('corte');

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-canvas text-ink">
        <a
          href="#conteudo-principal"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[60] focus:rounded-sm focus:bg-gold focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-gold-ink"
        >
          Pular para o conteúdo principal
        </a>

        <Navbar />

        <main id="conteudo-principal">
          <HeroSection />
          <ServicesSection onSelectService={setSelectedServiceId} />
          <AboutGallerySection />
          <ContactBookingSection selectedServiceId={selectedServiceId} />
        </main>

        <Footer />
      </div>
    </MotionConfig>
  );
}
