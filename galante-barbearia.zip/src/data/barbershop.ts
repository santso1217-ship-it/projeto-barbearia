import heroImage from '../assets/images/hero_galante_barbershop_1794577596383.jpg';
import corteImage from '../assets/images/service_corte_masculino_1794577596166.jpg';
import barbaImage from '../assets/images/service_barba_navalha_1794577597196.jpg';
import tratamentoImage from '../assets/images/service_tratamento_capilar_1794577597370.jpg';
import barberPortrait from '../assets/images/gallery_barber_craft_clean_1794577611649.jpg';

export interface ServiceItem {
  id: 'corte' | 'barba' | 'tratamento';
  index: string;
  name: string;
  price: number;
  priceFormatted: string;
  description: string;
  image: string;
  imageAlt: string;
}

export interface StatMetric {
  value: string;
  label: string;
}

export const BARBERSHOP_INFO = {
  name: 'Galante Barbearia',
  city: 'Sumaré - SP',
  address: 'R. Ângelo Ôngaro, 300 - Centro, Sumaré - SP, 13170-024',
  phoneDisplay: '+55 19 98406-4616',
  whatsappDigits: '5519984064616',
} as const;

export function buildWhatsAppUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${BARBERSHOP_INFO.whatsappDigits}?text=${encoded}`;
}

export const HERO_MEDIA = {
  image: heroImage,
  alt: 'Interior clássico da Galante Barbearia com cadeiras de couro e iluminação dourada em Sumaré',
};

export const ABOUT_MEDIA = {
  image: barberPortrait,
  alt: 'Mestre barbeiro da Galante Barbearia ao lado de cadeira clássica de couro e latão',
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'corte',
    index: '01',
    name: 'Corte Masculino',
    price: 60,
    priceFormatted: 'R$ 60',
    description:
      'Tesoura, máquina e acabamento na navalha pensados para o caimento natural do seu cabelo.',
    image: corteImage,
    imageAlt: 'Barbeiro realizando corte masculino de precisão com tesoura na Galante Barbearia',
  },
  {
    id: 'barba',
    index: '02',
    name: 'Barba',
    price: 45,
    priceFormatted: 'R$ 45',
    description:
      'Ritual clássico com toalha quente, espuma hidratante e contorno preciso na navalha.',
    image: barbaImage,
    imageAlt: 'Barbeiro fazendo alinhamento de barba na navalha com toalha quente',
  },
  {
    id: 'tratamento',
    index: '03',
    name: 'Tratamento Capilar',
    price: 80,
    priceFormatted: 'R$ 80',
    description:
      'Hidratação profunda e cuidado do couro cabeludo com séruns botânicos e massagem relaxante.',
    image: tratamentoImage,
    imageAlt: 'Aplicação de tratamento capilar nutritivo com toalha aquecida na barbearia',
  },
];

export const STATS: StatMetric[] = [
  { value: '15+', label: 'Anos de experiência' },
  { value: '10.000+', label: 'Clientes atendidos' },
  { value: '5', label: 'Barbeiros especialistas' },
  { value: '4.9', label: 'Nota de avaliação' },
];
