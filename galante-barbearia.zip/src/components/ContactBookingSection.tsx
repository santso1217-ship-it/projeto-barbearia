import { useEffect, useState, type FormEvent } from 'react';
import { CheckCircle2, MapPin, MessageCircle, Phone } from 'lucide-react';
import {
  BARBERSHOP_INFO,
  SERVICES,
  buildWhatsAppUrl,
  type ServiceItem,
} from '../data/barbershop';
import { ScrollReveal } from './MotionPrimitives';

type BookingOptionId = ServiceItem['id'] | 'combo';

interface BookingOption {
  id: BookingOptionId;
  label: string;
  price: string;
}

const BOOKING_OPTIONS: BookingOption[] = [
  ...SERVICES.map((s) => ({
    id: s.id,
    label: s.name,
    price: s.priceFormatted,
  })),
  {
    id: 'combo',
    label: 'Corte + Barba',
    price: 'R$ 105',
  },
];

const PERIOD_OPTIONS = ['Manhã', 'Tarde', 'Noite'] as const;

interface ContactBookingSectionProps {
  selectedServiceId: ServiceItem['id'];
}

export function ContactBookingSection({ selectedServiceId }: ContactBookingSectionProps) {
  const [serviceId, setServiceId] = useState<BookingOptionId>(selectedServiceId);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [period, setPeriod] = useState<(typeof PERIOD_OPTIONS)[number]>('Tarde');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ name?: string; phone?: string; date?: string }>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  useEffect(() => {
    setServiceId(selectedServiceId);
  }, [selectedServiceId]);

  const activeService =
    BOOKING_OPTIONS.find((item) => item.id === serviceId) ?? BOOKING_OPTIONS[0];

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    BARBERSHOP_INFO.address
  )}`;

  const directWhatsAppUrl = buildWhatsAppUrl(
    'Olá! Gostaria de agendar um horário na Galante Barbearia.'
  );

  const validate = () => {
    const nextErrors: { name?: string; phone?: string; date?: string } = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp válido com DDD.';
    }
    if (!date) {
      nextErrors.date = 'Selecione a data desejada.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validate()) return;

    const formattedDate = date.split('-').reverse().join('/');
    const messageLines = [
      `Olá, Galante Barbearia! Gostaria de agendar:`,
      `• Serviço: ${activeService.label} (${activeService.price})`,
      `• Nome: ${name.trim()}`,
      `• WhatsApp: ${phone.trim()}`,
      `• Data desejada: ${formattedDate}`,
      `• Período preferido: ${period}`,
    ];

    if (notes.trim()) {
      messageLines.push(`• Observação: ${notes.trim()}`);
    }

    const url = buildWhatsAppUrl(messageLines.join('\n'));
    setSubmittedUrl(url);
  };

  const resetForm = () => {
    setSubmittedUrl(null);
    setErrors({});
  };

  const todayIso = new Date().toISOString().split('T')[0];

  return (
    <section
      id="contato"
      aria-labelledby="contato-heading"
      className="border-t border-line/70 bg-surface py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 gap-14 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Real Location & Direct WhatsApp */}
          <ScrollReveal className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <p className="text-xs font-medium tracking-[0.14em] uppercase text-gold">
                Contato &amp; Localização
              </p>
              <h2
                id="contato-heading"
                className="mt-4 font-display font-semibold tracking-tight text-ink leading-[1.06]"
                style={{ fontSize: 'clamp(2rem, 4vw, 3.25rem)' }}
              >
                Sua cadeira espera por você.
              </h2>
              <p className="mt-5 text-base leading-relaxed text-ink-secondary">
                Atendimento personalizado no centro de Sumaré. Confirme disponibilidade de
                horários diretamente pelo WhatsApp.
              </p>

              <div className="mt-10 space-y-6 border-t border-line pt-8">
                <div className="flex items-start gap-4">
                  <MapPin className="mt-1 h-5 w-5 shrink-0 text-gold" aria-hidden="true" />
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.1em] text-ink-muted">
                      Endereço
                    </p>
                    <p className="mt-1 text-sm sm:text-base text-ink leading-relaxed">
                      {BARBERSHOP_INFO.address}
                    </p>
                    <a
                      href={mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-xs font-semibold text-gold underline underline-offset-4 hover:text-gold-hover"
                    >
                      Abrir no Google Maps
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="mt-1 h-5 w-5 shrink-0 text-gold" aria-hidden="true" />
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.1em] text-ink-muted">
                      Telefone &amp; WhatsApp
                    </p>
                    <a
                      href={`tel:+${BARBERSHOP_INFO.whatsappDigits}`}
                      className="mt-1 inline-block text-sm sm:text-base text-ink tabular-nums-strict hover:text-gold transition-colors"
                    >
                      {BARBERSHOP_INFO.phoneDisplay}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-8 border-t border-line/70">
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] w-full sm:w-auto items-center justify-center gap-2.5 rounded-sm bg-gold px-7 py-3.5 text-sm font-semibold tracking-wide text-gold-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-gold-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </ScrollReveal>

          {/* Right Column: Interactive Online Booking Form */}
          <ScrollReveal className="lg:col-span-7" delay={0.1}>
            <div
              id="agendamento"
              className="rounded-sm border border-line bg-canvas p-6 sm:p-10 scroll-mt-24"
            >
              <div className="border-b border-line pb-6">
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-ink">
                  Agendamento Online
                </h3>
                <p className="mt-2 text-sm text-ink-secondary">
                  Selecione o serviço e envie sua preferência diretamente para nosso WhatsApp.
                </p>
              </div>

              {submittedUrl ? (
                <div className="py-10 space-y-6">
                  <div className="flex items-start gap-4">
                    <CheckCircle2
                      className="mt-0.5 h-6 w-6 shrink-0 text-gold"
                      aria-hidden="true"
                    />
                    <div>
                      <h4 className="font-display text-xl font-semibold text-ink">
                        Solicitação pronta para envio
                      </h4>
                      <p className="mt-2 text-sm leading-relaxed text-ink-secondary">
                        Serviço selecionado:{' '}
                        <strong className="text-ink">
                          {activeService.label} ({activeService.price})
                        </strong>
                        . Clique abaixo para concluir seu atendimento no WhatsApp.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 pt-2">
                    <a
                      href={submittedUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-sm bg-gold px-7 py-3.5 text-sm font-semibold text-gold-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-gold-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden="true" />
                      <span>Confirmar no WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={resetForm}
                      className="inline-flex min-h-[44px] items-center justify-center rounded-sm border border-line px-5 py-2.5 text-sm font-medium text-ink-secondary whitespace-nowrap shrink-0 transition-colors hover:border-gold hover:text-ink cursor-pointer"
                    >
                      Alterar dados
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-6">
                  {/* Interactive Service Segmented Selector */}
                  <div>
                    <span className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary">
                      Serviço desejado
                    </span>
                    <div
                      role="group"
                      aria-label="Escolha o serviço"
                      className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2"
                    >
                      {BOOKING_OPTIONS.map((option) => {
                        const isSelected = serviceId === option.id;
                        return (
                          <button
                            key={option.id}
                            type="button"
                            onClick={() => setServiceId(option.id)}
                            aria-pressed={isSelected}
                            className={`flex min-h-[48px] items-center justify-between gap-3 rounded-sm border px-4 py-3 text-left text-sm transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold ${
                              isSelected
                                ? 'border-gold bg-surface-elevated text-ink'
                                : 'border-line bg-surface/50 text-ink-secondary hover:border-gold/50 hover:text-ink'
                            }`}
                          >
                            <span className="font-medium truncate">{option.label}</span>
                            <span
                              className={`font-display font-semibold tabular-nums-strict whitespace-nowrap shrink-0 ${
                                isSelected ? 'text-gold' : 'text-ink-muted'
                              }`}
                            >
                              {option.price}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Name & WhatsApp */}
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="booking-name"
                        className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary"
                      >
                        Nome completo
                      </label>
                      <input
                        id="booking-name"
                        type="text"
                        autoComplete="name"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                        }}
                        placeholder="Seu nome"
                        aria-invalid={Boolean(errors.name)}
                        className="mt-2 w-full min-h-[44px] rounded-sm border border-line bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-ink-muted focus:border-gold focus:outline-none"
                      />
                      {errors.name && (
                        <p role="alert" className="mt-1.5 text-xs text-gold">
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="booking-phone"
                        className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary"
                      >
                        Seu WhatsApp
                      </label>
                      <input
                        id="booking-phone"
                        type="tel"
                        autoComplete="tel"
                        value={phone}
                        onChange={(e) => {
                          setPhone(e.target.value);
                          if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                        }}
                        placeholder="(19) 99999-9999"
                        aria-invalid={Boolean(errors.phone)}
                        className="mt-2 w-full min-h-[44px] rounded-sm border border-line bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-ink-muted tabular-nums-strict focus:border-gold focus:outline-none"
                      />
                      {errors.phone && (
                        <p role="alert" className="mt-1.5 text-xs text-gold">
                          {errors.phone}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Date & Period */}
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="booking-date"
                        className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary"
                      >
                        Data desejada
                      </label>
                      <input
                        id="booking-date"
                        type="date"
                        min={todayIso}
                        value={date}
                        onChange={(e) => {
                          setDate(e.target.value);
                          if (errors.date) setErrors((prev) => ({ ...prev, date: undefined }));
                        }}
                        aria-invalid={Boolean(errors.date)}
                        className="mt-2 w-full min-h-[44px] rounded-sm border border-line bg-surface px-4 py-2.5 text-sm text-ink tabular-nums-strict focus:border-gold focus:outline-none"
                      />
                      {errors.date && (
                        <p role="alert" className="mt-1.5 text-xs text-gold">
                          {errors.date}
                        </p>
                      )}
                    </div>

                    <div>
                      <span className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary">
                        Turno preferido
                      </span>
                      <div
                        role="group"
                        aria-label="Turno preferido"
                        className="mt-2 grid grid-cols-3 gap-2"
                      >
                        {PERIOD_OPTIONS.map((item) => {
                          const active = period === item;
                          return (
                            <button
                              key={item}
                              type="button"
                              onClick={() => setPeriod(item)}
                              aria-pressed={active}
                              className={`min-h-[44px] rounded-sm border px-3 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold ${
                                active
                                  ? 'border-gold bg-surface-elevated text-gold'
                                  : 'border-line bg-surface text-ink-secondary hover:border-gold/50 hover:text-ink'
                              }`}
                            >
                              {item}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Optional Notes */}
                  <div>
                    <label
                      htmlFor="booking-notes"
                      className="block text-xs font-medium uppercase tracking-[0.1em] text-ink-secondary"
                    >
                      Observação (opcional)
                    </label>
                    <input
                      id="booking-notes"
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Ex.: preferência de barbeiro ou estilo de corte"
                      className="mt-2 w-full min-h-[44px] rounded-sm border border-line bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-ink-muted focus:border-gold focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="inline-flex min-h-[48px] w-full items-center justify-center gap-2.5 rounded-sm bg-gold px-7 py-3.5 text-sm font-semibold tracking-wide text-gold-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-gold-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold cursor-pointer"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden="true" />
                      <span>Solicitar Horário no WhatsApp</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
