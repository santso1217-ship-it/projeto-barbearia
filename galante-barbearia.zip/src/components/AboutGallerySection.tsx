import { ArrowDownRight } from 'lucide-react';
import { ABOUT_MEDIA, STATS } from '../data/barbershop';
import { ScrollReveal } from './MotionPrimitives';
import { ResilientImage } from './ResilientImage';

export function AboutGallerySection() {
  return (
    <section
      id="sobre"
      aria-labelledby="sobre-heading"
      className="border-t border-line/70 bg-canvas py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16 items-stretch">
          {/* Left: Vertical Editorial Portrait */}
          <ScrollReveal className="lg:col-span-5 flex flex-col">
            <figure className="flex flex-1 flex-col">
              <div className="relative flex-1 min-h-[420px] overflow-hidden rounded-sm border border-line bg-surface-elevated">
                <ResilientImage
                  src={ABOUT_MEDIA.image}
                  alt={ABOUT_MEDIA.alt}
                  className="h-full w-full object-cover object-top"
                />
              </div>
              <figcaption className="mt-4 flex items-center justify-between text-xs text-ink-muted">
                <span>Ofício clássico e atendimento pessoal</span>
                <span aria-hidden="true" className="text-gold">
                  Sumaré · SP
                </span>
              </figcaption>
            </figure>
          </ScrollReveal>

          {/* Right: Authoritative Narrative + Proof Metrics Strip */}
          <ScrollReveal
            className="lg:col-span-7 flex flex-col justify-between py-2"
            delay={0.1}
          >
            <div>
              <p className="text-xs font-medium tracking-[0.14em] uppercase text-gold">
                Sobre Nós
              </p>
              <h2
                id="sobre-heading"
                className="mt-4 font-display font-semibold tracking-tight text-ink leading-[1.06]"
                style={{ fontSize: 'clamp(2.1rem, 4.2vw, 3.4rem)' }}
              >
                Tradição construída no detalhe.
              </h2>

              <div className="mt-8 space-y-5 max-w-xl text-base leading-relaxed text-ink-secondary">
                <p>
                  Na Galante Barbearia, cada atendimento respeita o tempo certo da tesoura,
                  da navalha e da boa conversa. Unimos técnicas clássicas de barbearia ao
                  acabamento contemporâneo que valoriza o estilo de cada cliente.
                </p>
                <p>
                  Com cinco barbeiros especialistas e mais de quinze anos de estrada,
                  mantemos o padrão que transformou a casa em referência de cuidado
                  masculino no centro de Sumaré.
                </p>
              </div>
            </div>

            {/* Clean Hairline-Divided Proof Metrics Strip */}
            <div className="mt-12 border-t border-line pt-10">
              <dl className="grid grid-cols-2 gap-x-8 gap-y-8 sm:grid-cols-4">
                {STATS.map((stat) => (
                  <div key={stat.label} className="flex flex-col">
                    <dt className="order-2 mt-2 text-xs sm:text-sm leading-snug text-ink-secondary">
                      {stat.label}
                    </dt>
                    <dd className="order-1 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-gold tabular-nums-strict">
                      {stat.value}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="mt-10 pt-8 border-t border-line/60">
                <a
                  href="#agendamento"
                  className="inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-gold focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold"
                >
                  <span>Reservar sua cadeira</span>
                  <ArrowDownRight className="h-4 w-4 text-gold" aria-hidden="true" />
                </a>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
