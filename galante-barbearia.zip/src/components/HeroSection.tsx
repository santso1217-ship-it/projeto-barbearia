import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { BARBERSHOP_INFO, HERO_MEDIA, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

const EASE_LUXURY = [0.16, 1, 0.3, 1] as const;

export function HeroSection() {
  const prefersReducedMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de conversar sobre horários na Galante Barbearia.'
  );

  return (
    <section
      id="inicio"
      className="relative flex min-h-[92svh] items-end overflow-hidden bg-canvas pt-24 pb-16 sm:pb-24"
    >
      {/* Full-bleed atmospheric backdrop */}
      <div className="absolute inset-0">
        <ResilientImage
          src={HERO_MEDIA.image}
          alt={HERO_MEDIA.alt}
          loading="eager"
          fetchPriority="high"
          className="h-full w-full object-cover object-center"
        />
        {/* Measured scrims ensuring WCAG AA+ contrast across all breakpoints */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-canvas via-canvas/80 to-canvas/35"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-canvas via-canvas/30 to-canvas/55"
        />
      </div>

      {/* Editorial Hero Composition */}
      <div className="relative z-10 mx-auto w-full max-w-6xl px-5 sm:px-8">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE_LUXURY }}
          className="max-w-3xl"
        >
          {/* Quiet unboxed metadata line */}
          <div className="mb-6 flex flex-wrap items-center gap-2 text-xs font-medium tracking-[0.14em] uppercase text-gold">
            <span>{BARBERSHOP_INFO.city}</span>
            <span aria-hidden="true" className="text-ink-muted">
              ·
            </span>
            <span className="text-ink-secondary">Atendimento com hora marcada</span>
          </div>

          {/* Dominant single H1 */}
          <h1
            className="font-display font-semibold tracking-tight text-ink leading-[0.98]"
            style={{ fontSize: 'clamp(3rem, 7.2vw, 6rem)' }}
          >
            Estilo <span className="italic text-gold font-medium">&amp;</span> Tradição
          </h1>

          {/* Short, confident supporting copy */}
          <p className="mt-6 max-w-lg text-base sm:text-lg leading-relaxed text-ink-secondary">
            Corte masculino, barba na navalha e cuidado clássico em Sumaré.
          </p>

          {/* Primary Decision Block */}
          <div className="mt-10 flex flex-wrap items-center gap-6">
            <a
              href="#agendamento"
              className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-sm bg-gold px-7 py-3.5 text-sm font-semibold tracking-wide text-gold-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-gold-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
            >
              <span>Agende seu Horário</span>
              <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
            </a>

            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-2 border-b border-gold/50 pb-1 text-sm font-medium text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-gold hover:text-gold focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold"
            >
              <MessageCircle className="h-4 w-4 text-gold" aria-hidden="true" />
              <span>Conversar no WhatsApp</span>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
