import { BARBERSHOP_INFO, buildWhatsAppUrl } from '../data/barbershop';

export function Footer() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Galante Barbearia.'
  );

  return (
    <footer className="border-t border-line bg-canvas py-12">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-5 sm:px-8 md:flex-row md:items-center md:justify-between">
        <div>
          <a
            href="#inicio"
            className="font-display text-lg font-semibold tracking-tight text-ink hover:text-gold transition-colors"
          >
            {BARBERSHOP_INFO.name}
          </a>
          <p className="mt-2 text-xs text-ink-muted">{BARBERSHOP_INFO.address}</p>
        </div>

        <nav
          aria-label="Rodapé"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-ink-secondary"
        >
          <a href="#inicio" className="hover:text-gold transition-colors">
            Início
          </a>
          <a href="#servicos" className="hover:text-gold transition-colors">
            Serviços
          </a>
          <a href="#sobre" className="hover:text-gold transition-colors">
            Sobre
          </a>
          <a href="#contato" className="hover:text-gold transition-colors">
            Contato
          </a>
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gold hover:text-gold-hover transition-colors"
          >
            WhatsApp
          </a>
        </nav>

        <p className="text-xs text-ink-muted">
          © {new Date().getFullYear()} {BARBERSHOP_INFO.name}
        </p>
      </div>
    </footer>
  );
}
