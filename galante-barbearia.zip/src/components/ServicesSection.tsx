import { ArrowUpRight } from 'lucide-react';
import { SERVICES, type ServiceItem } from '../data/barbershop';
import { ScrollReveal } from './MotionPrimitives';
import { ResilientImage } from './ResilientImage';

interface ServicesSectionProps {
  onSelectService: (serviceId: ServiceItem['id']) => void;
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const [corte, barba, tratamento] = SERVICES;

  const handleBookClick = (serviceId: ServiceItem['id']) => {
    onSelectService(serviceId);
    const target = document.getElementById('agendamento');
    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section
      id="servicos"
      aria-labelledby="servicos-heading"
      className="border-t border-line/70 bg-surface py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        {/* Section Heading */}
        <ScrollReveal>
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-line pb-10">
            <div>
              <p className="text-xs font-medium tracking-[0.14em] uppercase text-gold">
                Nossos Serviços
              </p>
              <h2
                id="servicos-heading"
                className="mt-3 font-display font-semibold tracking-tight text-ink leading-[1.06]"
                style={{ fontSize: 'clamp(2rem, 4vw, 3.25rem)' }}
              >
                Precisão em cada cadeira.
              </h2>
            </div>
            <p className="max-w-sm text-sm sm:text-base leading-relaxed text-ink-secondary">
              Escolha o ritual ideal e confirme seu horário diretamente pelo WhatsApp.
            </p>
          </div>
        </ScrollReveal>

        {/* Asymmetric Bento Showcase — 01 (Wide) + 02 (Upright) + 03 (Horizontal Split) */}
        <div className="mt-14 grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* 01. Corte Masculino — Dominant 7-col feature */}
          <ScrollReveal className="lg:col-span-7 flex" delay={0.05}>
            <article className="group flex w-full flex-col overflow-hidden rounded-sm border border-line bg-canvas/55 transition-colors duration-200 hover:border-gold/50">
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={corte.image}
                  alt={corte.imageAlt}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
                <div>
                  <div className="flex items-baseline justify-between gap-4">
                    <h3 className="font-display text-2xl sm:text-3xl font-semibold text-ink">
                      {corte.index}. {corte.name}
                    </h3>
                    <span className="font-display text-2xl sm:text-3xl font-semibold text-gold tabular-nums-strict whitespace-nowrap shrink-0">
                      {corte.priceFormatted}
                    </span>
                  </div>
                  <p className="mt-3 max-w-xl text-sm sm:text-base leading-relaxed text-ink-secondary">
                    {corte.description}
                  </p>
                </div>

                <div className="mt-8 pt-5 border-t border-line/70">
                  <button
                    type="button"
                    onClick={() => handleBookClick(corte.id)}
                    className="inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-gold whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-gold-hover focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold cursor-pointer"
                  >
                    <span>Agendar {corte.name}</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          </ScrollReveal>

          {/* 02. Barba — Complementary 5-col feature */}
          <ScrollReveal className="lg:col-span-5 flex" delay={0.12}>
            <article className="group flex w-full flex-col overflow-hidden rounded-sm border border-line bg-canvas/55 transition-colors duration-200 hover:border-gold/50">
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={barba.image}
                  alt={barba.imageAlt}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
                <div>
                  <div className="flex items-baseline justify-between gap-4">
                    <h3 className="font-display text-2xl sm:text-3xl font-semibold text-ink">
                      {barba.index}. {barba.name}
                    </h3>
                    <span className="font-display text-2xl sm:text-3xl font-semibold text-gold tabular-nums-strict whitespace-nowrap shrink-0">
                      {barba.priceFormatted}
                    </span>
                  </div>
                  <p className="mt-3 text-sm sm:text-base leading-relaxed text-ink-secondary">
                    {barba.description}
                  </p>
                </div>

                <div className="mt-8 pt-5 border-t border-line/70">
                  <button
                    type="button"
                    onClick={() => handleBookClick(barba.id)}
                    className="inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-gold whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-gold-hover focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold cursor-pointer"
                  >
                    <span>Agendar {barba.name}</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          </ScrollReveal>

          {/* 03. Tratamento Capilar — Full-width horizontal editorial split */}
          <ScrollReveal className="lg:col-span-12" delay={0.16}>
            <article className="group grid grid-cols-1 overflow-hidden rounded-sm border border-line bg-canvas/55 transition-colors duration-200 hover:border-gold/50 lg:grid-cols-12 items-stretch">
              <div className="relative aspect-[4/3] lg:aspect-auto lg:col-span-6 overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={tratamento.image}
                  alt={tratamento.imageAlt}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>

              <div className="flex flex-col justify-between p-6 sm:p-10 lg:col-span-6 lg:p-12">
                <div>
                  <div className="flex flex-wrap items-baseline justify-between gap-4">
                    <h3 className="font-display text-2xl sm:text-3xl lg:text-4xl font-semibold text-ink">
                      {tratamento.index}. {tratamento.name}
                    </h3>
                    <span className="font-display text-2xl sm:text-3xl lg:text-4xl font-semibold text-gold tabular-nums-strict whitespace-nowrap shrink-0">
                      {tratamento.priceFormatted}
                    </span>
                  </div>
                  <p className="mt-4 max-w-lg text-sm sm:text-base leading-relaxed text-ink-secondary">
                    {tratamento.description}
                  </p>
                </div>

                <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-line/70 pt-6">
                  <span className="text-xs font-medium tracking-[0.12em] uppercase text-ink-muted">
                    Cuidado intensivo · Produtos selecionados
                  </span>
                  <button
                    type="button"
                    onClick={() => handleBookClick(tratamento.id)}
                    className="inline-flex min-h-[44px] items-center gap-2 rounded-sm border border-gold/60 px-5 py-2.5 text-sm font-semibold text-gold whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-gold hover:text-gold-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold cursor-pointer"
                  >
                    <span>Agendar Tratamento</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
